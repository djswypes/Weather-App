package olaoluwa.w_clima

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
